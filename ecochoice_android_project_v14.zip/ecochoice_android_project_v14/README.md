# EcoChoice Android v14

v14: мульти-источники данных. Добавлен поиск/дополнение через USDA FoodData Central DEMO_KEY, вкладка Источники, поддержка API-ключей Go-UPC, Barcode Lookup и EAN-DB, показатель полноты данных и объединение данных Open Food Facts + USDA, если в одной базе не хватает состава или бренда.
