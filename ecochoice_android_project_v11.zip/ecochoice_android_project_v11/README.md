# EcoChoice Android v11

v11 improves online product cards: missing-ingredient flow, food metadata, safer packaging handling, and alternative suggestions.
