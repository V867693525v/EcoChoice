@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.ecochoice.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ecochoice.app.ui.theme.EcoChoiceTheme
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EcoChoiceTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    EcoChoiceApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcoChoiceApp() {
    var currentScreen by rememberSaveable { mutableStateOf("home") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var barcodeInput by rememberSaveable { mutableStateOf("") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var manualName by rememberSaveable { mutableStateOf("") }
    var manualIngredients by rememberSaveable { mutableStateOf("") }
    var manualResult by remember { mutableStateOf<EcoResult?>(null) }
    val products = remember { sampleProducts() }

    fun openByBarcode(code: String) {
        barcodeInput = code
        selectedProduct = products.firstOrNull { it.barcode == code }
        currentScreen = if (selectedProduct != null) "detail" else "notfound"
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("EcoChoice") },
                navigationIcon = {
                    if (currentScreen != "home") {
                        IconButton(onClick = { currentScreen = "home" }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null)
                        }
                    }
                }
            )
        }
    ) { padding ->
        when (currentScreen) {
            "home" -> HomeScreen(
                modifier = Modifier.padding(padding),
                products = products,
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                barcodeInput = barcodeInput,
                onBarcodeInputChange = { barcodeInput = it },
                onOpenProduct = {
                    selectedProduct = it
                    currentScreen = "detail"
                },
                onBarcodeCheck = { openByBarcode(barcodeInput.trim()) },
                onOpenScanner = { currentScreen = "scanner" },
                onManualOpen = { currentScreen = "manual" }
            )
            "detail" -> selectedProduct?.let {
                ProductDetailScreen(
                    modifier = Modifier.padding(padding),
                    product = it,
                    alternatives = products.filter { p -> p.category == it.category && p.id != it.id }
                        .sortedByDescending { p -> calculateEco(p).score }
                        .take(3)
                )
            }
            "notfound" -> NotFoundScreen(modifier = Modifier.padding(padding), barcode = barcodeInput)
            "scanner" -> ScannerScreen(
                modifier = Modifier.padding(padding),
                onDetected = { openByBarcode(it) }
            )
            "manual" -> ManualAnalysisScreen(
                modifier = Modifier.padding(padding),
                name = manualName,
                ingredients = manualIngredients,
                onNameChange = { manualName = it },
                onIngredientsChange = { manualIngredients = it },
                result = manualResult,
                onAnalyze = {
                    val product = Product(
                        id = "manual",
                        barcode = "manual",
                        name = if (manualName.isBlank()) "Ручной анализ" else manualName,
                        brand = "Ваш товар",
                        category = "Домашняя проверка",
                        ingredients = manualIngredients.split(",").map { text -> text.trim() }.filter { text -> text.isNotBlank() },
                        packageType = PackageType.PLASTIC,
                        refillable = false,
                        crueltyFree = false,
                        local = false,
                        description = "Демо-анализ по введенному составу"
                    )
                    manualResult = calculateEco(product)
                }
            )
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    products: List<Product>,
    query: String,
    onQueryChange: (String) -> Unit,
    barcodeInput: String,
    onBarcodeInputChange: (String) -> Unit,
    onOpenProduct: (Product) -> Unit,
    onBarcodeCheck: () -> Unit,
    onOpenScanner: () -> Unit,
    onManualOpen: () -> Unit,
) {
    val filtered = remember(query, products) {
        if (query.isBlank()) products else products.filter {
            listOf(it.name, it.brand, it.barcode, it.category, it.ingredients.joinToString(" "))
                .joinToString(" ")
                .contains(query, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Проверяй товары дома и в магазине", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Можно искать товар, ввести штрихкод или открыть сканер камеры.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        label = { Text("Поиск по базе") },
                        placeholder = { Text("Например: шампунь, уксус, PureDrop") }
                    )
                    OutlinedTextField(
                        value = barcodeInput,
                        onValueChange = onBarcodeInputChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Штрихкод") },
                        placeholder = { Text("Введи код вручную") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onBarcodeCheck) { Text("Проверить") }
                        OutlinedButton(onClick = onOpenScanner) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null)
                            Spacer(Modifier.size(6.dp))
                            Text("Сканер")
                        }
                        OutlinedButton(onClick = onManualOpen) { Text("Состав") }
                    }
                }
            }
        }
        items(filtered) { product ->
            ProductCard(product = product, onOpen = { onOpenProduct(product) })
        }
    }
}

@Composable
fun ProductCard(product: Product, onOpen: () -> Unit) {
    val result = calculateEco(product)
    Card(
        onClick = onOpen,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(product.category) })
                AssistChip(
                    onClick = {},
                    colors = AssistChipDefaults.assistChipColors(containerColor = result.gradeColor.copy(alpha = 0.14f)),
                    label = { Text("Eco ${result.grade} • ${result.score}/100") }
                )
            }
            Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(product.brand, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (product.refillable) Tag("Refill")
                if (product.crueltyFree) Tag("Cruelty-free")
                if (product.local) Tag("Локальный")
                Tag(product.barcode)
            }
        }
    }
}

@Composable
fun ProductDetailScreen(modifier: Modifier = Modifier, product: Product, alternatives: List<Product>) {
    val result = calculateEco(product)
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {}, label = { Text(product.category) })
                    AssistChip(
                        onClick = {},
                        colors = AssistChipDefaults.assistChipColors(containerColor = result.gradeColor.copy(alpha = 0.14f)),
                        label = { Text("Eco ${result.grade}") }
                    )
                }
                Text(product.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(product.brand, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${result.score}/100", style = MaterialTheme.typography.displaySmall, color = result.gradeColor, fontWeight = FontWeight.Bold)
                Text(result.label, style = MaterialTheme.typography.titleMedium)
            }
        }

        InfoSection(title = "Почему такая оценка") {
            result.reasons.forEach { reason ->
                Text("• $reason", modifier = Modifier.padding(vertical = 4.dp))
            }
        }

        InfoSection(title = "Состав") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                product.ingredients.forEach { Tag(it) }
            }
        }

        InfoSection(title = "Чем заменить") {
            alternatives.filter { calculateEco(it).score > result.score }.ifEmpty { alternatives }.take(3).forEach { alt ->
                val altResult = calculateEco(alt)
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(alt.name, fontWeight = FontWeight.SemiBold)
                        Text(alt.brand, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${altResult.score}/100 • ${altResult.label}", color = altResult.gradeColor)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun ManualAnalysisScreen(
    modifier: Modifier = Modifier,
    name: String,
    ingredients: String,
    onNameChange: (String) -> Unit,
    onIngredientsChange: (String) -> Unit,
    result: EcoResult?,
    onAnalyze: () -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ручной анализ состава", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = name, onValueChange = onNameChange, modifier = Modifier.fillMaxWidth(), label = { Text("Название товара") })
        OutlinedTextField(
            value = ingredients,
            onValueChange = onIngredientsChange,
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
            label = { Text("Состав через запятую") },
            placeholder = { Text("water, SLES, fragrance, colorant") }
        )
        Button(onClick = onAnalyze) { Text("Рассчитать") }
        result?.let {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Результат: ${it.score}/100", style = MaterialTheme.typography.headlineMedium, color = it.gradeColor, fontWeight = FontWeight.Bold)
                    Text(it.label, style = MaterialTheme.typography.titleMedium)
                    it.reasons.forEach { reason -> Text("• $reason") }
                }
            }
        }
    }
}

@Composable
fun NotFoundScreen(modifier: Modifier = Modifier, barcode: String) {
    Box(modifier = modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
        Card(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Товар не найден", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Штрихкод: $barcode")
                Text("Сейчас в проекте встроенная демо-база. Следующий шаг — подключить реальную внешнюю базу товаров.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ScannerScreen(modifier: Modifier = Modifier, onDetected: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    Column(modifier = modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Сканирование штрихкода", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Наведи камеру на код. Если он есть в базе MVP, приложение сразу откроет карточку товара.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (!hasPermission) {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Нужно разрешение на камеру")
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Разрешить") }
                }
            }
        } else {
            val executor = remember { Executors.newSingleThreadExecutor() }
            DisposableEffect(Unit) {
                onDispose { executor.shutdown() }
            }
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black, RoundedCornerShape(28.dp)),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        val options = BarcodeScanning.getClient()
                        val imageAnalyzer = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also { analysis ->
                                analysis.setAnalyzer(executor) { imageProxy ->
                                    val mediaImage = imageProxy.image
                                    if (mediaImage != null) {
                                        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                        options.process(image)
                                            .addOnSuccessListener { barcodes ->
                                                val code = barcodes.firstOrNull()?.rawValue
                                                if (!code.isNullOrBlank()) {
                                                    coroutineScope.launch { onDetected(code) }
                                                }
                                            }
                                            .addOnCompleteListener { imageProxy.close() }
                                    } else {
                                        imageProxy.close()
                                    }
                                }
                            }
                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                imageAnalyzer
                            )
                        } catch (_: Exception) {
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Тестовые коды MVP", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("4601234000011", "4601234000012", "4770001112223", "4770001112224", "5909000003331", "4777001234567").forEach { code ->
                        FilterChip(selected = false, onClick = { onDetected(code) }, label = { Text(code) })
                    }
                }
            }
        }
    }
}

@Composable
fun InfoSection(title: String, content: @Composable () -> Unit) {
    Card(shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun Tag(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
    }
}

enum class PackageType { PLASTIC, RECYCLED_PLASTIC, GLASS, CARDBOARD }

data class Product(
    val id: String,
    val barcode: String,
    val name: String,
    val brand: String,
    val category: String,
    val ingredients: List<String>,
    val packageType: PackageType,
    val refillable: Boolean,
    val crueltyFree: Boolean,
    val local: Boolean,
    val description: String,
)

data class EcoResult(
    val score: Int,
    val grade: String,
    val label: String,
    val reasons: List<String>,
    val gradeColor: Color,
)

fun calculateEco(product: Product): EcoResult {
    var score = 50
    val reasons = mutableListOf<String>()
    val normalized = product.ingredients.map { it.lowercase() }

    normalized.forEach { ingredient ->
        if ("sls" in ingredient) {
            score -= 18
            reasons += "Содержит SLS — более агрессивный ПАВ."
        }
        if ("sles" in ingredient) {
            score -= 12
            reasons += "Содержит SLES — не самый экологичный ПАВ."
        }
        if ("fragrance" in ingredient) {
            score -= 10
            reasons += "Есть синтетическая отдушка."
        }
        if ("colorant" in ingredient) {
            score -= 8
            reasons += "Есть красители без пользы для функции продукта."
        }
        if ("paraben" in ingredient) {
            score -= 9
            reasons += "Есть парабены."
        }
        if ("silicone" in ingredient) {
            score -= 8
            reasons += "Есть силиконы."
        }
        if ("bleach" in ingredient) {
            score -= 12
            reasons += "Есть отбеливающий компонент."
        }
        if ("quats" in ingredient) {
            score -= 14
            reasons += "Есть кватернерные соединения."
        }
        if ("plant surfactants" in ingredient) {
            score += 10
            reasons += "Используются растительные ПАВы."
        }
        if ("mild surfactants" in ingredient) {
            score += 12
            reasons += "Используются мягкие ПАВы."
        }
        if ("citric acid" in ingredient) {
            score += 7
            reasons += "Есть лимонная кислота — более мягкий компонент."
        }
        if ("vinegar" in ingredient) {
            score += 8
            reasons += "Есть уксус — простой и понятный компонент."
        }
        if ("aloe" in ingredient) {
            score += 5
            reasons += "Есть алоэ."
        }
        if ("betaine" in ingredient) {
            score += 5
            reasons += "Есть бетаин."
        }
    }

    when (product.packageType) {
        PackageType.PLASTIC -> {
            score -= 10
            reasons += "Обычный пластиковый флакон снижает оценку."
        }
        PackageType.RECYCLED_PLASTIC -> {
            score += 4
            reasons += "Использован переработанный пластик."
        }
        PackageType.GLASS -> {
            score += 8
            reasons += "Стеклянная упаковка лучше перерабатывается."
        }
        PackageType.CARDBOARD -> {
            score += 10
            reasons += "Картонная упаковка обычно экологичнее пластика."
        }
    }

    if (product.refillable) {
        score += 12
        reasons += "Есть refill / возможность дозаправки."
    }
    if (product.crueltyFree) {
        score += 10
        reasons += "Бренд заявлен как cruelty-free."
    }
    if (product.local) {
        score += 6
        reasons += "Локальный бренд — короче логистика."
    }

    score = score.coerceIn(0, 100)
    val grade = when {
        score >= 80 -> "A"
        score >= 65 -> "B"
        score >= 45 -> "C"
        else -> "D"
    }
    val label = when (grade) {
        "A" -> "Очень хороший эко-выбор"
        "B" -> "Хороший выбор"
        "C" -> "Средний выбор"
        else -> "Лучше поискать альтернативу"
    }
    val color = when (grade) {
        "A" -> Color(0xFF16A34A)
        "B" -> Color(0xFF65A30D)
        "C" -> Color(0xFFD97706)
        else -> Color(0xFFE11D48)
    }

    return EcoResult(score = score, grade = grade, label = label, reasons = reasons.distinct(), gradeColor = color)
}

fun sampleProducts() = listOf(
    Product(
        id = "1",
        barcode = "4601234000011",
        name = "Средство для мытья посуды Lemon Power",
        brand = "Cleanix",
        category = "Бытовая химия",
        ingredients = listOf("SLES", "fragrance", "colorant", "sodium chloride", "preservative"),
        packageType = PackageType.PLASTIC,
        refillable = false,
        crueltyFree = false,
        local = false,
        description = "Обычное средство для посуды с яркой отдушкой."
    ),
    Product(
        id = "2",
        barcode = "4601234000012",
        name = "Eco Dish Gel Unscented",
        brand = "PureDrop",
        category = "Бытовая химия",
        ingredients = listOf("plant surfactants", "citric acid", "salt", "water"),
        packageType = PackageType.RECYCLED_PLASTIC,
        refillable = true,
        crueltyFree = true,
        local = false,
        description = "Мягкий гель для посуды без отдушки, есть рефил."
    ),
    Product(
        id = "3",
        barcode = "4770001112223",
        name = "Универсальный очиститель Pine Fresh",
        brand = "HomePro",
        category = "Бытовая химия",
        ingredients = listOf("bleach", "fragrance", "quats", "colorant"),
        packageType = PackageType.PLASTIC,
        refillable = false,
        crueltyFree = false,
        local = false,
        description = "Сильный очиститель для кухни и ванной."
    ),
    Product(
        id = "4",
        barcode = "4770001112224",
        name = "Eco Multi Surface Spray",
        brand = "Žalia Namai",
        category = "Бытовая химия",
        ingredients = listOf("vinegar", "plant surfactants", "water", "natural preservative"),
        packageType = PackageType.GLASS,
        refillable = true,
        crueltyFree = true,
        local = true,
        description = "Мягкий спрей для поверхностей в стеклянной таре."
    ),
    Product(
        id = "5",
        barcode = "5909000003331",
        name = "Шампунь Volume Boost",
        brand = "GlossUp",
        category = "Уход",
        ingredients = listOf("SLS", "silicone", "fragrance", "paraben"),
        packageType = PackageType.PLASTIC,
        refillable = false,
        crueltyFree = false,
        local = false,
        description = "Классический шампунь с сильной пеной и силиконами."
    ),
    Product(
        id = "6",
        barcode = "4772220004449",
        name = "Таблетки для посудомойки Eco Tabs",
        brand = "PureDrop",
        category = "Бытовая химия",
        ingredients = listOf("oxygen bleach", "enzymes", "citric acid"),
        packageType = PackageType.CARDBOARD,
        refillable = false,
        crueltyFree = true,
        local = false,
        description = "Таблетки в картонной упаковке без лишней отдушки."
    ),
    Product(
        id = "7",
        barcode = "4777001234567",
        name = "Баланс-шампунь Herbal Soft",
        brand = "Žalia Care",
        category = "Уход",
        ingredients = listOf("mild surfactants", "aloe", "betaine", "natural fragrance"),
        packageType = PackageType.RECYCLED_PLASTIC,
        refillable = true,
        crueltyFree = true,
        local = true,
        description = "Более мягкий шампунь с простой формулой."
    )
)
