package com.ecochoice.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF15803D),
    secondary = Color(0xFF65A30D),
    tertiary = Color(0xFF0F766E),
    background = Color(0xFFF8FAF8),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE8F5E9)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    secondary = Color(0xFFA3E635),
    tertiary = Color(0xFF5EEAD4)
)

@Composable
fun EcoChoiceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
