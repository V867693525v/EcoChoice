plugins {
    id("com.android.application")
}

android {
    namespace = "com.ecochoice.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ecochoice.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}
