# EcoChoice Android APK project

Minimal Android WebView project for EcoChoice. Builds a debug APK with a local offline app, manual barcode input, product database, manual ingredient analysis, and camera access via WebView.
