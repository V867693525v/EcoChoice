# EcoChoice v15

Android WebView MVP: scanner + multi-source lookup + nutrition/additives/allergens + category insights.
