EcoChoice Android project v16

Расширенная карточка Open Food Facts: питание, NOVA, добавки, фото этикеток, упаковка, паспорт товара.
