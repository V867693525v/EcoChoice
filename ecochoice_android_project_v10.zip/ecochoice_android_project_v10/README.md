# EcoChoice Android v10

v10 adds online lookup by barcode using Open Food Facts, Open Beauty Facts and Open Products Facts, plus local cache fallback and manual add if not found.
