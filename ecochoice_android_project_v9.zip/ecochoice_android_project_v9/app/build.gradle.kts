plugins {
    id("com.android.application")
}

android {
    namespace = "com.ecochoice.app"
    compileSdk = 34

    signingConfigs {
        create("ecochoiceStable") {
            storeFile = file("ecochoice-stable-debug.p12")
            storePassword = "ecochoice"
            keyAlias = "ecochoice"
            keyPassword = "ecochoice"
            storeType = "pkcs12"
        }
    }

    defaultConfig {
        applicationId = "com.ecochoice.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 9
        versionName = "0.9"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("ecochoiceStable")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("ecochoiceStable")
            isMinifyEnabled = false
        }
    }
}
